using NUnit.Framework;
using CalculateLibrary;
using System.Collections.Generic;
using System;

namespace Tests
{


	public class Tests
	{

		private Calcualor _calculator;
		string _filename = "inputfile_1.txt";
		//Test File Existance 
		[Test]
		public void TestInputfileExist()
		{
			_filename = "inputfile_1.txt";
			_calculator = new Calcualor(_filename);
			bool IsfileExist = _calculator.IsFileExist(_filename);
			//_calculator = new 
			Assert.AreEqual(true, IsfileExist);
		}



		/*
		 * Test Valid Values for a given instructions
		 * */

		[Test]

		public void TestIsValidContent()
		{
		   // string[] instructions = new string[]();
		string[] validvalues = new string[3] {"add 2","multiply 3", "apply 3" };
		string filename = "inputfile_1.txt";
		_calculator = new Calcualor(filename);
		foreach ( var content in validvalues )
			{
				bool expectedvalue = true;
				Assert.AreEqual(expectedvalue, _calculator.IsValidContent(content));
			}
			
		}

		//Test scenario 1 
		[Test]
		public void TestIsValidTotalCase1()
		{

			string[] validvalues = new string[3] { "add 2", "multiply 3", "apply 3" };
			string filename = "inputfile_1.txt";
			_calculator = new Calcualor(filename);
			
			// string[] instructions = new string[]();
			Dictionary<string, string> ValidValues = new Dictionary<string, string>();
			ValidValues.Add("add", "2");
			ValidValues.Add("multiply", "3");
			ValidValues.Add("apply", "3");
			Int64 expectedtotal = 15;
			Assert.AreEqual(expectedtotal, _calculator.Calculator(ValidValues));
			}

		//Test scenario 2
		[Test]
		public void TestIsValidTotalCase2()
		{

			string[] validvalues = new string[2] { "multiply 9","apply 5" };
			string filename = "inputfile_2.txt";
			_calculator = new Calcualor(filename);

			// string[] instructions = new string[]();
			Dictionary<string, string> ValidValues = new Dictionary<string, string>();
			ValidValues.Add("multiply", "9");
			ValidValues.Add("apply", "5");
			Int64 expectedtotal = 45;
			Assert.AreEqual(expectedtotal, _calculator.Calculator(ValidValues));
		}




	}
}