﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace CalculateLibrary
{

	public class Calcualor
	{
		private string _filename;

		public Calcualor(string filename)
		{

			this._filename = filename;
		}

		public bool IsFileExist(string filename)
		{
			string path = Path.GetDirectoryName(System.AppDomain.CurrentDomain.BaseDirectory);
			return File.Exists((Path.GetDirectoryName(System.AppDomain.CurrentDomain.BaseDirectory) + "\\" + filename));

		}

		public bool IsValidContent(string content)
		{

			string pattren = @"add(?<middle>\d+)|subtract(?<middle>\d+)|multiply(?<middle>\d+)|divide(?<middle>\d+)|apply(?<middle>\d+)";
			Regex expression = new Regex(pattren); // (multiply(?<middle>\d+))");
			Match ismatch = expression.Match(content.Replace(" ", ""));
			return ismatch.Success;
		}

		public  Int64 Calculator(Dictionary<string, string> ValidValues)
		{
			Int64 result = 0;
			Int64 initialValue = 0;
			if (ValidValues.ContainsKey("apply"))
			{
				Int64.TryParse(ValidValues["apply"], out initialValue);

				result = initialValue;
				foreach (var kvp in ValidValues)
				{
					Int64 cvalue;
					Int64.TryParse(ValidValues[kvp.Key], out cvalue);
					//calculatortags[kvp.Key,
					switch (kvp.Key)
					{

						case "add":
							{
								result += cvalue;
								break;
							}

						case "subtract":
							{
								result -= cvalue;
								break;
							}

						case "multiply":
							{
								result *= cvalue;
								break;
							}

						case "divide":
							{
								if (cvalue != 0)
								{
									result /= cvalue;
								}
								break;

							}
						default:
							break;



					}


				}


			}

			return result;
		}


	}



}

