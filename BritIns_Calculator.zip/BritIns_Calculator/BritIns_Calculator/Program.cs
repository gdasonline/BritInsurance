﻿using CalculateLibrary;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace BritIns_Calculator
{
	class Program
	{
		

		static void Main(string[] args)
		{
			/*
			 * C# Write some code to calculate a result from a set of instructions.
			*Instructions comprise a keyword and a number that are separated by a space per line. Instructions are loaded from file and results are output to the screen. Any number of Instructions can be specified.
			*Instructions should be the add, divide, multiply and subtract operators, ignoring mathematical precedence. The last instruction should be "apply" and a number (e.g., "apply 3"). The calculator is then initialised with that number and the previous instructions are applied to that number.

			 * */
			string[] instructions;
				string filename = "inputfile_1.txt";
				Calcualor _calculator = new Calcualor(filename);
			    
				if  (_calculator.IsFileExist(filename))
			
				{

				StreamReader file = new StreamReader(filename);
				string line;
				Dictionary<string, string> calculatortags = new Dictionary<string, string>();

				while ((line = file.ReadLine()) != null)
				{  
			
					Console.WriteLine(line);
					string instruction = RemoveDuplicateSpaces(line).ToLower();
					 if (_calculator.IsValidContent(line))
					{
						instructions = instruction.Split(' ');
						if ((instructions.Length) <= 2)
							calculatortags.Add(instructions[0], instructions[1]);
					}
				}
				var total = _calculator.Calculator(calculatortags);
				

				Console.WriteLine(string.Format("{0}", total.ToString()));
				 
			}


		}
			//remove duplicate spaces
			static string RemoveDuplicateSpaces(string instruction) 
			{
				var  noduplicateinstruction = string.Join(" ", instruction.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries));
				return noduplicateinstruction;
			}

	

}
}

